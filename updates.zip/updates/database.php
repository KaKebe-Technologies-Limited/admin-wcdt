<?php
$hostName = "localhost";
$userName = "rgxszumy_administrator";
$password = "Jps, 18cf3";
$databaseName = "gxszumy_worshipcenter";
 $conn = new mysqli($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

